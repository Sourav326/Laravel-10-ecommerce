<?php $__env->startSection('content'); ?>
<div class="row pb-4">
    <div class="col-sm-6">
        <h3 class="mb-0 font-weight-bold">Brand List</h3>
    </div>
</div>
<div class="col-lg-12 grid-margin stretch-card">
              <div class="card">
                <div class="card-body">
                    <div class="d-flex justify-content-between align-items-center">

                        <h4 class="card-title">Brand Details</h4>
                        <a href="<?php echo e(route('admin.brands.create')); ?>">
                        <button type="button" class="btn btn-success btn-icon-text">
                        <i class="typcn typcn-input-checked btn-icon-prepend"></i>                                                   
                                Add Brand
                              </button>
                              </a>
                    </div>
                  <div class="table-responsive">
                    <table class="table table-striped">
                      <thead>
                        <tr>
                          <th>
                            Brand Logo
                          </th>
                          <th>
                          Brand Title
                          </th>
                          <th>
                            Status
                          </th>
                          <th>
                            Category
                          </th>
                          <th>
                            Created date
                          </th>
                          <th>
                            Action
                          </th>
                        </tr>
                      </thead>
                      <tbody>
                        <?php $__empty_1 = true; $__currentLoopData = $brands; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $brand): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                        <tr>
                          <td class="py-1">
                            <img src="<?php echo e(asset('storage/images/brands').'/'.$brand->logo); ?>" alt="<?php echo e($brand->logo); ?>">
                          </td>
                          <td>
                            <?php echo e($brand->title); ?>

                          </td>
                          <td>
                            <a href="<?php echo e(route('admin.brands.updateStatus',['id' => $brand->id])); ?>">
                                <?php if($brand->status == 0): ?>
                                    <label class="badge badge-success">Active</label>
                                <?php else: ?>
                                    <label class="badge badge-danger">Deactive</label>
                                <?php endif; ?>
                            </a>
                          </td>
                          <td>
                           Pupular
                          </td>
                          <td>
                            May 15, 2015
                          </td>
                          <td>
                          <label class="badge badge-info">View</label>
                          <label class="badge badge-danger">Delete</label>
                          </td>
                        </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                        <p>No Brands Available</p>
                        <?php endif; ?>
                          
                      </tbody>
                    </table>
                    <?php echo e($brands->links()); ?>

                  </div>
                </div>
              </div>
            </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Users/souravchauhan/Developer/winningkart/winningkart/resources/views/admin/brand/index.blade.php ENDPATH**/ ?>