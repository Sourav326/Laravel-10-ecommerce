
<?php if($paginator->hasPages()): ?>
    <div class="btn-group mt-4" role="group" aria-label="Basic example">
        <?php if($paginator->onFirstPage()): ?>
            <span class="paginateNext btn btn-outline-secondary" disabled aria-hidden="true">&laquo;</span>
        <?php else: ?>
            <a class="btn btn-outline-secondary " href="<?php echo e($paginator->previousPageUrl()); ?>" rel="prev" aria-label="<?php echo app('translator')->get('pagination.previous'); ?>">&laquo;</a>
        <?php endif; ?>
        <?php $__currentLoopData = $elements; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $element): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            
            <?php if(is_string($element)): ?>
                <span class="paginateNext btn btn-outline-secondary"><?php echo e($element); ?></span>
            <?php endif; ?>

            
            <?php if(is_array($element)): ?>
                <?php $__currentLoopData = $element; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $page => $url): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <?php if($page == $paginator->currentPage()): ?>
                        <span class="active paginateNext btn btn-outline-secondary"><?php echo e($page); ?></span>
                    <?php else: ?>
                        <a class="btn btn-outline-secondary" href="<?php echo e($url); ?>" rel="prev"><?php echo e($page); ?></a>
                    <?php endif; ?>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            <?php endif; ?>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

        <?php if($paginator->hasMorePages()): ?>
            <a href="<?php echo e($paginator->nextPageUrl()); ?>" class="btn btn-outline-secondary" rel="next" aria-label="<?php echo app('translator')->get('pagination.next'); ?>">&raquo;</a>
        <?php else: ?>
            <span class="paginateNext btn btn-outline-secondary" disabled aria-hidden="true">&raquo;</span>
        <?php endif; ?>
    </div>
<?php endif; ?><?php /**PATH /Users/souravchauhan/Developer/winningkart/winningkart/resources/views/admin/pagination/pagination.blade.php ENDPATH**/ ?>