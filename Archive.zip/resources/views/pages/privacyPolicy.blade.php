@extends('layouts.app')
@section('content')


<section class="policySec">
    <div class="container">
        <div class="policyMain">
            <h1 class="text-center">Privacy Policy</h1>
            <div class="brandDesc">

                <p>Lorem ipsum dolor sit amet consectetur adipisicing elit. Earum, distinctio? Dolores quia libero atque
                    repellat mollitia ex distinctio vel quo?
                    Lorem ipsum dolor sit amet consectetur adipisicing elit. Earum, distinctio? Dolores quia libero
                    atque repellat mollitia ex distinctio vel quo?
                    Lorem ipsum dolor sit amet consectetur adipisicing elit. Earum, distinctio? Dolores quia libero
                    atque repellat mollitia ex distinctio vel quo?
                </p>
                <h2>Lorem ipsum dolor sit amet consectetur, adipisicing elit.</h2>
                <p>Lorem ipsum dolor sit amet consectetur adipisicing elit. Earum, distinctio? Dolores quia libero atque
                    repellat mollitia ex distinctio vel quo?
                    Lorem ipsum dolor sit amet consectetur adipisicing elit. Earum, distinctio? Dolores quia libero
                    atque repellat mollitia ex distinctio vel quo?
                    Lorem ipsum dolor sit amet consectetur adipisicing elit. Earum, distinctio? Dolores quia libero
                    atque repellat mollitia ex distinctio vel quo?
                </p>
                <h3>Lorem ipsum dolor sit amet consectetur, adipisicing elit.</h3>
                <p>Lorem ipsum dolor sit amet consectetur adipisicing elit. Earum, distinctio? Dolores quia libero atque
                    repellat mollitia ex distinctio vel quo?
                    Lorem ipsum dolor sit amet consectetur adipisicing elit. Earum, distinctio? Dolores quia libero
                    atque repellat mollitia ex distinctio vel quo?
                    Lorem ipsum dolor sit amet consectetur adipisicing elit. Earum, distinctio? Dolores quia libero
                    atque repellat mollitia ex distinctio vel quo?
                </p>
                <ul>
                    <li>Lorem ipsum dolor sit amet consectetur adipisicing elit. Nemo, voluptatum!</li>
                    <li>Lorem ipsum dolor sit amet consectetur adipisicing elit. Nemo, voluptatum!</li>
                    <li>Lorem ipsum dolor sit amet consectetur adipisicing elit. Nemo, voluptatum!</li>
                    <li>Lorem ipsum dolor sit amet consectetur adipisicing elit. Nemo, voluptatum!</li>
                </ul>
            </div>
        </div>
    </div>
</section>


@endsection